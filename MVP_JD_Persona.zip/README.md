# Persona Wizard — TypeScript Starter (Light)

## Quick start
```bash
npm install
npm run dev
```

## Next
- Replace `src/App.tsx` with your Persona Wizard TS component.
- Ensure you keep `import './index.css'` in your entry.
